#pragma once
#include <QColor>
#include <QString>

namespace Theme {
const QColor bgTop(0x1e, 0x1e, 0x24);
const QColor bgBottom(0x12, 0x12, 0x14);
const QColor cyan(0x00, 0xff, 0xcc);
const QColor amber(0xff, 0xaa, 0x00);
const QColor red(0xff, 0x6b, 0x6b);
const QColor text(0xe0, 0xe0, 0xe0);

inline QString menuStyle()
{
    return QStringLiteral(
        "QMenu { background-color:#1a1a24; color:#e0e0e0; border:1px solid #33334d;"
        "        border-radius:8px; padding:6px; }"
        "QMenu::item { padding:8px 26px 8px 12px; border-radius:4px; margin:2px; }"
        "QMenu::item:selected { background-color:#007acc; color:#ffffff; }"
        "QMenu::item:disabled { color:#777788; }"
        "QMenu::separator { height:1px; background:#33334d; margin:4px 8px; }"
        "QMenu::icon { padding-left:6px; }");
}

inline QString dialogStyle()
{
    return QStringLiteral(
        "QDialog, QInputDialog { background-color:#1a1a24; color:#e0e0e0; }"
        "QLabel { color:#e0e0e0; }"
        "QLineEdit { background:#121214; color:#00ffcc; border:1px solid #33334d;"
        "            border-radius:4px; padding:5px; }"
        "QPushButton { background:#007acc; color:white; border:none; border-radius:4px;"
        "              padding:6px 16px; }"
        "QPushButton:hover { background:#1992e0; }");
}
} // namespace Theme

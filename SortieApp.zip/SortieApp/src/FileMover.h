#pragma once
#include <QString>

struct MoveResult {
    bool ok = false;
    QString finalPath;
    QString message; // error, or warning when ok == true
};

namespace FileMover {
// Moves a file or folder into destDir.
//  - creates destDir if missing
//  - never overwrites: name conflicts become "name_copy1.ext", "name_copy2.ext", ...
//  - tries a fast rename first, falls back to copy + verify + delete (cross-drive moves)
MoveResult move(const QString &source, const QString &destDir);
} // namespace FileMover

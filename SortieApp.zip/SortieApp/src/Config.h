#pragma once
#include <QList>
#include <QPoint>
#include <QString>

struct Petal {
    QString name;
    QString path;
};

struct AppConfig {
    int widgetSize = 180;
    bool hasPos = false;
    QPoint pos;
    bool alwaysOnTop = true;
    QList<Petal> petals;
};

namespace ConfigStore {
constexpr int kMinSize = 100;
constexpr int kMaxSize = 400;
constexpr int kDefaultSize = 180;

// petals_config.json next to the exe; falls back to the user config dir if the exe folder is read-only.
QString filePath();
AppConfig load();
bool save(const AppConfig &cfg); // atomic (QSaveFile: temp file + rename on commit)
} // namespace ConfigStore

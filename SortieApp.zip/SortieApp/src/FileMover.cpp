#include "FileMover.h"

#include <QDir>
#include <QDirIterator>
#include <QFile>
#include <QFileInfo>

namespace {

QString uniquePath(const QDir &dir, const QFileInfo &src)
{
    QString candidate = dir.absoluteFilePath(src.fileName());
    if (!QFileInfo::exists(candidate))
        return candidate;

    const bool isDir = src.isDir();
    const QString base = isDir ? src.fileName() : src.completeBaseName();
    const QString ext = isDir ? QString() : src.suffix();

    for (int i = 1; i < 100000; ++i) {
        const QString name = ext.isEmpty() ? QString("%1_copy%2").arg(base).arg(i)
                                           : QString("%1_copy%2.%3").arg(base).arg(i).arg(ext);
        candidate = dir.absoluteFilePath(name);
        if (!QFileInfo::exists(candidate))
            return candidate;
    }
    return QString();
}

bool copyRecursive(const QString &src, const QString &dst)
{
    QDir().mkpath(dst);
    const QDir srcDir(src);
    const QFileInfoList entries = srcDir.entryInfoList(
        QDir::AllEntries | QDir::NoDotAndDotDot | QDir::Hidden | QDir::System);
    for (const QFileInfo &e : entries) {
        const QString target = QDir(dst).filePath(e.fileName());
        if (e.isDir() && !e.isSymLink()) {
            if (!copyRecursive(e.absoluteFilePath(), target))
                return false;
        } else if (!QFile::copy(e.absoluteFilePath(), target)) {
            return false;
        }
    }
    return true;
}

qint64 treeSize(const QString &path)
{
    QFileInfo fi(path);
    if (!fi.isDir())
        return fi.size();
    qint64 total = 0;
    QDirIterator it(path, QDir::Files | QDir::Hidden | QDir::System, QDirIterator::Subdirectories);
    while (it.hasNext()) {
        it.next();
        total += it.fileInfo().size();
    }
    return total;
}

} // namespace

namespace FileMover {

MoveResult move(const QString &source, const QString &destDirStr)
{
    MoveResult r;
    const QFileInfo src(source);
    if (!src.exists()) {
        r.message = "Source no longer exists.";
        return r;
    }

    QDir destDir(destDirStr);
    if (!destDir.exists() && !destDir.mkpath(".")) {
        r.message = "Cannot create destination folder.";
        return r;
    }

    const QString srcAbs = src.absoluteFilePath();
    const QString destAbs = QFileInfo(destDir.absolutePath()).absoluteFilePath();

    if (QDir::cleanPath(src.absolutePath()) == QDir::cleanPath(destAbs)) {
        r.message = "File is already in that folder.";
        return r;
    }
    if (src.isDir() && (destAbs == srcAbs || destAbs.startsWith(srcAbs + "/"))) {
        r.message = "Cannot move a folder into itself.";
        return r;
    }

    const QString dst = uniquePath(destDir, src);
    if (dst.isEmpty()) {
        r.message = "Could not find a free file name.";
        return r;
    }

    // 1) Fast path: same-volume rename
    bool renamed = src.isDir() ? QDir().rename(srcAbs, dst) : QFile::rename(srcAbs, dst);
    if (renamed) {
        r.ok = true;
        r.finalPath = dst;
        return r;
    }

    // 2) Fallback: copy -> verify -> delete original (cross-drive / cross-partition)
    const bool copied = src.isDir() ? copyRecursive(srcAbs, dst) : QFile::copy(srcAbs, dst);
    if (!copied || treeSize(srcAbs) != treeSize(dst)) {
        // roll back the partial copy; the original is untouched
        if (src.isDir())
            QDir(dst).removeRecursively();
        else
            QFile::remove(dst);
        r.message = "Copy failed (disk full, permission denied, or file in use). Original kept.";
        return r;
    }

    const bool removed = src.isDir() ? QDir(srcAbs).removeRecursively() : QFile::remove(srcAbs);
    r.ok = true;
    r.finalPath = dst;
    if (!removed)
        r.message = "Copied, but the original could not be deleted.";
    return r;
}

} // namespace FileMover

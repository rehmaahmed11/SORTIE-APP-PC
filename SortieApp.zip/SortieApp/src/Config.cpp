#include "Config.h"

#include <QCoreApplication>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QSaveFile>
#include <QStandardPaths>

namespace ConfigStore {

QString filePath()
{
    const QString appDir = QCoreApplication::applicationDirPath();
    const QString local = QDir(appDir).filePath("petals_config.json");

    // Use the exe folder if we can write there (or the file already exists and is writable).
    if (QFileInfo::exists(local)) {
        if (QFileInfo(local).isWritable())
            return local;
    } else if (QFileInfo(appDir).isWritable()) {
        return local;
    }

    const QString dir = QStandardPaths::writableLocation(QStandardPaths::AppConfigLocation);
    QDir().mkpath(dir);
    return QDir(dir).filePath("petals_config.json");
}

AppConfig load()
{
    AppConfig cfg;
    QFile f(filePath());
    if (!f.open(QIODevice::ReadOnly))
        return cfg;

    const QJsonDocument doc = QJsonDocument::fromJson(f.readAll());
    if (!doc.isObject())
        return cfg;

    const QJsonObject o = doc.object();
    cfg.widgetSize = qBound(kMinSize, o.value("widget_size").toInt(kDefaultSize), kMaxSize);
    cfg.alwaysOnTop = o.value("always_on_top").toBool(true);
    if (o.contains("x") && o.contains("y")) {
        cfg.hasPos = true;
        cfg.pos = QPoint(o.value("x").toInt(), o.value("y").toInt());
    }

    const QJsonArray arr = o.value("folders").toArray();
    for (const QJsonValue &v : arr) {
        const QJsonObject po = v.toObject();
        Petal p;
        p.name = po.value("name").toString();
        p.path = po.value("path").toString();
        if (p.name.isEmpty())
            p.name = QFileInfo(p.path).fileName();
        if (!p.path.isEmpty())
            cfg.petals.append(p);
    }
    return cfg;
}

bool save(const AppConfig &cfg)
{
    QJsonObject o;
    o["widget_size"] = cfg.widgetSize;
    o["always_on_top"] = cfg.alwaysOnTop;
    if (cfg.hasPos) {
        o["x"] = cfg.pos.x();
        o["y"] = cfg.pos.y();
    }
    QJsonArray arr;
    for (const Petal &p : cfg.petals) {
        QJsonObject po;
        po["name"] = p.name;
        po["path"] = p.path;
        arr.append(po);
    }
    o["folders"] = arr;

    QSaveFile f(filePath());
    if (!f.open(QIODevice::WriteOnly))
        return false;
    f.write(QJsonDocument(o).toJson(QJsonDocument::Indented));
    return f.commit();
}

} // namespace ConfigStore

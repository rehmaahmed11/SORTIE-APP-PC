#pragma once
#include <QTimer>
#include <QWidget>

#include "Config.h"

class DropZoneWidget : public QWidget {
    Q_OBJECT
public:
    explicit DropZoneWidget(QWidget *parent = nullptr);
    ~DropZoneWidget() override;

public slots:
    void addPetalInteractive();
    void resetSize();
    void setAlwaysOnTop(bool on);

protected:
    void paintEvent(QPaintEvent *) override;
    void wheelEvent(QWheelEvent *e) override;
    void mousePressEvent(QMouseEvent *e) override;
    void mouseMoveEvent(QMouseEvent *e) override;
    void mouseReleaseEvent(QMouseEvent *e) override;
    void mouseDoubleClickEvent(QMouseEvent *e) override;
    void contextMenuEvent(QContextMenuEvent *e) override;
    void dragEnterEvent(QDragEnterEvent *e) override;
    void dragLeaveEvent(QDragLeaveEvent *e) override;
    void dropEvent(QDropEvent *e) override;

private:
    void applySize(int newSize);
    void scheduleSave();
    void saveNow();
    void restorePosition();
    void applyWindowFlags();

    void showPetalMenu(const QStringList &files, const QPoint &globalPos);
    void moveFiles(const QStringList &files, const QString &destDir);
    void renamePetal(int index);
    void removePetal(int index);
    void showStatus(const QString &title, const QString &sub, bool error);

    AppConfig m_cfg;
    bool m_dragOver = false;
    bool m_statusError = false;
    bool m_menuOpen = false;
    QString m_statusTitle;
    QString m_statusSub;
    QPoint m_dragOffset;
    QTimer m_saveTimer;
    QTimer m_statusTimer;
};

#include "DropZoneWidget.h"

#include <QApplication>
#include <QContextMenuEvent>
#include <QDir>
#include <QDragEnterEvent>
#include <QDragLeaveEvent>
#include <QDropEvent>
#include <QFileDialog>
#include <QFileInfo>
#include <QGuiApplication>
#include <QIcon>
#include <QInputDialog>
#include <QLinearGradient>
#include <QMenu>
#include <QMimeData>
#include <QMouseEvent>
#include <QPainter>
#include <QPen>
#include <QRadialGradient>
#include <QScreen>
#include <QWheelEvent>

#include "FileMover.h"
#include "Theme.h"

DropZoneWidget::DropZoneWidget(QWidget *parent) : QWidget(parent)
{
    m_cfg = ConfigStore::load();

    setAttribute(Qt::WA_TranslucentBackground);
    setAcceptDrops(true);
    setWindowTitle("Sortie");
    setWindowIcon(QIcon(":/assets/icons/app_icon.svg"));
    applyWindowFlags();
    setFixedSize(m_cfg.widgetSize, m_cfg.widgetSize);
    restorePosition();

    m_saveTimer.setSingleShot(true);
    m_saveTimer.setInterval(400);
    connect(&m_saveTimer, &QTimer::timeout, this, &DropZoneWidget::saveNow);

    m_statusTimer.setSingleShot(true);
    m_statusTimer.setInterval(2200);
    connect(&m_statusTimer, &QTimer::timeout, this, [this]() {
        m_statusTitle.clear();
        m_statusSub.clear();
        m_statusError = false;
        update();
    });
}

DropZoneWidget::~DropZoneWidget()
{
    if (m_saveTimer.isActive())
        saveNow();
}

// ---------------------------------------------------------------- window / config

void DropZoneWidget::applyWindowFlags()
{
    Qt::WindowFlags f = Qt::Tool | Qt::FramelessWindowHint;
    if (m_cfg.alwaysOnTop)
        f |= Qt::WindowStaysOnTopHint;
    setWindowFlags(f);
}

void DropZoneWidget::setAlwaysOnTop(bool on)
{
    m_cfg.alwaysOnTop = on;
    const bool wasVisible = isVisible();
    applyWindowFlags(); // changing flags hides the window
    if (wasVisible)
        show();
    scheduleSave();
}

void DropZoneWidget::restorePosition()
{
    if (m_cfg.hasPos) {
        for (QScreen *s : QGuiApplication::screens()) {
            if (s->availableGeometry().contains(m_cfg.pos + QPoint(width() / 2, height() / 2))) {
                move(m_cfg.pos);
                return;
            }
        }
    }
    const QRect avail = QGuiApplication::primaryScreen()->availableGeometry();
    move(avail.right() - width() - 40, avail.bottom() - height() - 40);
}

void DropZoneWidget::scheduleSave()
{
    m_saveTimer.start();
}

void DropZoneWidget::saveNow()
{
    m_cfg.pos = pos();
    m_cfg.hasPos = true;
    m_cfg.widgetSize = width();
    ConfigStore::save(m_cfg);
}

void DropZoneWidget::applySize(int newSize)
{
    newSize = qBound(ConfigStore::kMinSize, newSize, ConfigStore::kMaxSize);
    if (newSize == width())
        return;
    const QPoint c = geometry().center(); // keep the widget centred while resizing
    setFixedSize(newSize, newSize);
    move(c - QPoint(newSize / 2, newSize / 2));
    update();
    scheduleSave();
}

void DropZoneWidget::resetSize()
{
    applySize(ConfigStore::kDefaultSize);
}

// ---------------------------------------------------------------- painting

void DropZoneWidget::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing);
    p.setRenderHint(QPainter::TextAntialiasing);

    const QRectF r = QRectF(rect()).adjusted(6, 6, -6, -6);
    const QColor accent = m_statusError ? Theme::red : (m_dragOver ? Theme::amber : Theme::cyan);

    // soft glow
    QRadialGradient glow(r.center(), r.width() / 2 + 6);
    QColor g0 = accent, g1 = accent;
    g0.setAlpha(0);
    g1.setAlpha(m_dragOver ? 110 : 45);
    glow.setColorAt(0.88, g0);
    glow.setColorAt(1.0, g1);
    p.setPen(Qt::NoPen);
    p.setBrush(glow);
    p.drawEllipse(rect().adjusted(1, 1, -1, -1));

    // body
    QLinearGradient body(r.topLeft(), r.bottomRight());
    body.setColorAt(0, m_dragOver ? QColor(0x24, 0x1a, 0x24) : Theme::bgTop);
    body.setColorAt(1, m_dragOver ? QColor(0x1e, 0x12, 0x18) : Theme::bgBottom);
    p.setBrush(body);
    QPen ring(accent, 2.5);
    ring.setStyle(m_dragOver ? Qt::SolidLine : Qt::DashLine);
    p.setPen(ring);
    p.drawEllipse(r);

    // text
    const bool status = !m_statusTitle.isEmpty();
    const QString title = status ? m_statusTitle : (m_dragOver ? "RELEASE" : "DROP HERE");
    const QString sub = status ? m_statusSub : (m_dragOver ? "to choose a folder" : "scroll to resize");

    QFont tf("Segoe UI");
    tf.setBold(true);
    tf.setPixelSize(qMax(10, width() / 11));
    QFont sf("Segoe UI");
    sf.setPixelSize(qMax(8, width() / 18));

    const QRectF tr(r.left(), r.top() + r.height() * 0.30, r.width(), r.height() * 0.22);
    const QRectF sr(r.left() + 8, r.top() + r.height() * 0.54, r.width() - 16, r.height() * 0.20);

    p.setPen(m_dragOver ? Qt::white : accent);
    p.setFont(tf);
    p.drawText(tr, Qt::AlignCenter, title);
    p.setPen(QColor(0xa0, 0xa0, 0xb0));
    p.setFont(sf);
    p.drawText(sr, Qt::AlignHCenter | Qt::AlignTop | Qt::TextWordWrap, sub);
}

// ---------------------------------------------------------------- mouse

void DropZoneWidget::wheelEvent(QWheelEvent *e)
{
    const int steps = e->angleDelta().y() / 120;
    if (steps != 0)
        applySize(width() + steps * 10);
    e->accept();
}

void DropZoneWidget::mousePressEvent(QMouseEvent *e)
{
    if (e->button() == Qt::LeftButton) {
        m_dragOffset = e->globalPosition().toPoint() - frameGeometry().topLeft();
        e->accept();
    }
}

void DropZoneWidget::mouseMoveEvent(QMouseEvent *e)
{
    if (e->buttons() & Qt::LeftButton) {
        move(e->globalPosition().toPoint() - m_dragOffset);
        e->accept();
    }
}

void DropZoneWidget::mouseReleaseEvent(QMouseEvent *e)
{
    if (e->button() == Qt::LeftButton)
        scheduleSave();
}

void DropZoneWidget::mouseDoubleClickEvent(QMouseEvent *e)
{
    if (e->button() == Qt::LeftButton) {
        resetSize();
        e->accept();
    }
}

void DropZoneWidget::contextMenuEvent(QContextMenuEvent *e)
{
    QMenu menu(this);
    menu.setStyleSheet(Theme::menuStyle());

    QAction *add = menu.addAction(QIcon(":/assets/icons/icon_add.svg"), "Add Folder...");
    QAction *reset = menu.addAction("Reset Size");
    QAction *top = menu.addAction("Always on Top");
    top->setCheckable(true);
    top->setChecked(m_cfg.alwaysOnTop);
    menu.addSeparator();
    QAction *quit = menu.addAction("Quit Sortie");

    QAction *chosen = menu.exec(e->globalPos());
    if (chosen == add)
        addPetalInteractive();
    else if (chosen == reset)
        resetSize();
    else if (chosen == top)
        setAlwaysOnTop(top->isChecked());
    else if (chosen == quit)
        QApplication::quit();
}

// ---------------------------------------------------------------- drag & drop

void DropZoneWidget::dragEnterEvent(QDragEnterEvent *e)
{
    if (e->mimeData()->hasUrls()) {
        e->acceptProposedAction();
        m_dragOver = true;
        update();
    }
}

void DropZoneWidget::dragLeaveEvent(QDragLeaveEvent *e)
{
    Q_UNUSED(e);
    m_dragOver = false;
    update();
}

void DropZoneWidget::dropEvent(QDropEvent *e)
{
    m_dragOver = false;
    update();

    QStringList files;
    for (const QUrl &u : e->mimeData()->urls()) {
        if (u.isLocalFile())
            files << u.toLocalFile();
    }
    if (files.isEmpty())
        return;

    e->acceptProposedAction();
    const QPoint globalPos = mapToGlobal(e->position().toPoint());

    // Show the menu after the drop handler returns so the drag source isn't blocked.
    QTimer::singleShot(0, this, [this, files, globalPos]() { showPetalMenu(files, globalPos); });
}

// ---------------------------------------------------------------- petal menu

void DropZoneWidget::showPetalMenu(const QStringList &files, const QPoint &globalPos)
{
    if (m_menuOpen)
        return;
    m_menuOpen = true;

    QMenu menu(this);
    menu.setStyleSheet(Theme::menuStyle());

    const QString header = files.size() == 1 ? QFileInfo(files.first()).fileName()
                                             : QString("%1 items").arg(files.size());
    QAction *hdr = menu.addAction(header);
    hdr->setEnabled(false);
    menu.addSeparator();

    QAction *actAdd = menu.addAction(QIcon(":/assets/icons/icon_add.svg"), "Add New Folder...");
    menu.addSeparator();

    if (m_cfg.petals.isEmpty()) {
        menu.addAction("(no folders yet - use Add New Folder)")->setEnabled(false);
    } else {
        for (int i = 0; i < m_cfg.petals.size(); ++i) {
            const Petal petal = m_cfg.petals.at(i);
            const bool missing = !QDir(petal.path).exists();
            QMenu *sub = menu.addMenu(QIcon(":/assets/icons/folder.svg"),
                                      missing ? petal.name + "  (will be created)" : petal.name);
            sub->setStyleSheet(Theme::menuStyle());
            sub->setToolTipsVisible(true);
            sub->setToolTip(QDir::toNativeSeparators(petal.path));

            QAction *mv = sub->addAction(QIcon(":/assets/icons/icon_move.svg"), "Move File Here");
            mv->setToolTip(QDir::toNativeSeparators(petal.path));
            QAction *rn = sub->addAction(QIcon(":/assets/icons/icon_settings.svg"), "Rename Petal...");
            QAction *rm = sub->addAction(QIcon(":/assets/icons/icon_remove.svg"), "Remove Petal");

            connect(mv, &QAction::triggered, this,
                    [this, files, petal]() { moveFiles(files, petal.path); });
            connect(rn, &QAction::triggered, this, [this, i]() { renamePetal(i); });
            connect(rm, &QAction::triggered, this, [this, i]() { removePetal(i); });
        }
    }

    menu.addSeparator();
    menu.addAction("Cancel");

    QAction *chosen = menu.exec(globalPos);
    if (chosen == actAdd) {
        // Add the folder, and if the user picked one, offer to send the dropped files there.
        const int before = m_cfg.petals.size();
        addPetalInteractive();
        if (m_cfg.petals.size() > before)
            moveFiles(files, m_cfg.petals.last().path);
    }
    m_menuOpen = false;
}

void DropZoneWidget::addPetalInteractive()
{
    const QString dirPath = QFileDialog::getExistingDirectory(
        this, "Select target folder for this petal", QDir::homePath());
    if (dirPath.isEmpty())
        return;

    const QString clean = QDir::cleanPath(dirPath);
    bool ok = false;
    QInputDialog dlg(this);
    dlg.setStyleSheet(Theme::dialogStyle());
    dlg.setWindowTitle("Name Petal");
    dlg.setLabelText("Display name for this folder:");
    dlg.setTextValue(QDir(clean).dirName().isEmpty() ? clean : QDir(clean).dirName());
    ok = dlg.exec() == QDialog::Accepted;
    const QString name = dlg.textValue().trimmed();
    if (!ok || name.isEmpty())
        return;

    m_cfg.petals.append({name, clean});
    saveNow();
}

void DropZoneWidget::renamePetal(int index)
{
    if (index < 0 || index >= m_cfg.petals.size())
        return;
    QInputDialog dlg(this);
    dlg.setStyleSheet(Theme::dialogStyle());
    dlg.setWindowTitle("Rename Petal");
    dlg.setLabelText("New name:");
    dlg.setTextValue(m_cfg.petals[index].name);
    if (dlg.exec() == QDialog::Accepted && !dlg.textValue().trimmed().isEmpty()) {
        m_cfg.petals[index].name = dlg.textValue().trimmed();
        saveNow();
    }
}

void DropZoneWidget::removePetal(int index)
{
    if (index < 0 || index >= m_cfg.petals.size())
        return;
    m_cfg.petals.removeAt(index); // only removes the shortcut, never the real folder
    saveNow();
}

// ---------------------------------------------------------------- moving

void DropZoneWidget::moveFiles(const QStringList &files, const QString &destDir)
{
    int okCount = 0;
    QString firstProblem;
    for (const QString &f : files) {
        const MoveResult r = FileMover::move(f, destDir);
        if (r.ok)
            ++okCount;
        if (!r.message.isEmpty() && firstProblem.isEmpty())
            firstProblem = r.message;
    }

    if (okCount == files.size() && firstProblem.isEmpty())
        showStatus("DONE", okCount == 1 ? "moved safely" : QString("%1 items moved").arg(okCount), false);
    else if (okCount > 0)
        showStatus("PARTIAL", QString("%1/%2 moved").arg(okCount).arg(files.size()), true);
    else
        showStatus("ERROR", firstProblem.isEmpty() ? "move failed" : firstProblem, true);

    if (!firstProblem.isEmpty())
        setToolTip(firstProblem);
}

void DropZoneWidget::showStatus(const QString &title, const QString &sub, bool error)
{
    m_statusTitle = title;
    m_statusSub = sub;
    m_statusError = error;
    m_statusTimer.start();
    update();
}

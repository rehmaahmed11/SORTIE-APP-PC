#include <QAction>
#include <QApplication>
#include <QIcon>
#include <QMenu>
#include <QSystemTrayIcon>

#include "DropZoneWidget.h"
#include "Theme.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    app.setApplicationName("Sortie");
    app.setOrganizationName("Sortie");
    app.setWindowIcon(QIcon(":/assets/icons/app_icon.svg"));
    app.setQuitOnLastWindowClosed(false); // lives in the tray

    DropZoneWidget widget;
    widget.show();

    QSystemTrayIcon *tray = nullptr;
    QMenu trayMenu;
    if (QSystemTrayIcon::isSystemTrayAvailable()) {
        trayMenu.setStyleSheet(Theme::menuStyle());
        QAction *show = trayMenu.addAction("Show Sortie");
        QAction *add = trayMenu.addAction(QIcon(":/assets/icons/icon_add.svg"), "Add Folder...");
        trayMenu.addSeparator();
        QAction *quit = trayMenu.addAction("Quit");

        QObject::connect(show, &QAction::triggered, &widget, [&widget]() {
            widget.show();
            widget.raise();
        });
        QObject::connect(add, &QAction::triggered, &widget, &DropZoneWidget::addPetalInteractive);
        QObject::connect(quit, &QAction::triggered, &app, &QApplication::quit);

        tray = new QSystemTrayIcon(QIcon(":/assets/icons/app_icon.svg"), &app);
        tray->setToolTip("Sortie - drop files to sort them");
        tray->setContextMenu(&trayMenu);
        QObject::connect(tray, &QSystemTrayIcon::activated, &widget,
                         [&widget](QSystemTrayIcon::ActivationReason r) {
                             if (r == QSystemTrayIcon::Trigger) {
                                 widget.show();
                                 widget.raise();
                             }
                         });
        tray->show();
    }

    return app.exec();
}

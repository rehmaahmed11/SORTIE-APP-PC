cmake_minimum_required(VERSION 3.16)
project(SortieApp VERSION 1.0.0 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_AUTOMOC ON)
set(CMAKE_AUTORCC ON)

find_package(Qt6 REQUIRED COMPONENTS Core Gui Widgets Svg)

add_executable(SortieApp WIN32
    src/main.cpp
    src/Config.cpp
    src/Config.h
    src/FileMover.cpp
    src/FileMover.h
    src/Theme.h
    src/DropZoneWidget.cpp
    src/DropZoneWidget.h
    resources.qrc
)

target_link_libraries(SortieApp PRIVATE Qt6::Core Qt6::Gui Qt6::Widgets Qt6::Svg)

# Windows packaging (windeployqt) is done by BUILD_SORTIE.bat into the Output folder.

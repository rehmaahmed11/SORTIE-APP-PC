@echo off
setlocal EnableExtensions
title Sortie App - Auto Builder
cd /d "%~dp0"
set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"
set "TC=%ROOT%\_toolchain"
set "BLD=%ROOT%\_build"
set "OUT=%ROOT%\Output"
set "QTVER=6.7.3"
set "CMAKEVER=3.29.6"
set "PYVER=3.12.7"

echo ==========================================================
echo   Sortie App - one click builder (Windows 10 64-bit)
echo   Already installed tools are detected and skipped.
echo   Missing tools are downloaded into: %TC%
echo   Final app goes to: %OUT%
echo ==========================================================
echo.

if not exist "%ROOT%\CMakeLists.txt" (
    echo ERROR: Keep this file in the SortieApp folder, next to CMakeLists.txt
    goto fail
)
if not exist "%TC%" mkdir "%TC%"

rem ---------------------------------------------------------- 1. CMake
echo [1/4] Checking CMake...
set "CMAKE="
if exist "%TC%\cmake\bin\cmake.exe" set "CMAKE=%TC%\cmake\bin\cmake.exe"
if not defined CMAKE (
    where cmake >nul 2>&1
    if not errorlevel 1 set "CMAKE=cmake"
)
if defined CMAKE (
    echo       found - skipping install.
    goto cmake_done
)
echo       not found - downloading CMake %CMAKEVER% ...
curl -L --fail -o "%TC%\cmake.zip" "https://github.com/Kitware/CMake/releases/download/v%CMAKEVER%/cmake-%CMAKEVER%-windows-x86_64.zip"
if errorlevel 1 goto fail
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force -LiteralPath '%TC%\cmake.zip' -DestinationPath '%TC%'"
if errorlevel 1 goto fail
if exist "%TC%\cmake" rmdir /s /q "%TC%\cmake"
for /d %%D in ("%TC%\cmake-*-windows-x86_64") do move "%%D" "%TC%\cmake" >nul
del /q "%TC%\cmake.zip" 2>nul
if not exist "%TC%\cmake\bin\cmake.exe" goto fail
set "CMAKE=%TC%\cmake\bin\cmake.exe"
:cmake_done

rem ---------------------------------------------------------- 2. Qt 6 + MinGW compiler
echo [2/4] Checking Qt 6 and MinGW compiler...
call :detect
if defined QTDIR if defined MINGW (
    echo       found - skipping install.
    goto qt_done
)

call :ensure_python
if errorlevel 1 goto fail

echo       installing aqtinstall ...
"%PY%" -m pip install --upgrade pip aqtinstall
if errorlevel 1 goto fail

if not defined QTDIR (
    echo       downloading Qt %QTVER% ^(MinGW 64-bit^) - this is a big download, please wait ...
    "%PY%" -m aqt install-qt windows desktop %QTVER% win64_mingw -O "%TC%\Qt"
    if errorlevel 1 goto fail
)
if not defined MINGW (
    echo       downloading MinGW compiler ...
    "%PY%" -m aqt install-tool windows desktop tools_mingw1120 qt.tools.win64_mingw1120 -O "%TC%\Qt"
    if errorlevel 1 (
        echo       retrying with MinGW 13.1 ...
        "%PY%" -m aqt install-tool windows desktop tools_mingw1310 qt.tools.win64_mingw1310 -O "%TC%\Qt"
        if errorlevel 1 goto fail
    )
)
call :detect
if not defined QTDIR (
    echo ERROR: Qt install finished but Qt folder was not found.
    goto fail
)
if not defined MINGW (
    echo ERROR: MinGW install finished but compiler was not found.
    goto fail
)
:qt_done
echo       Qt:    %QTDIR%
echo       MinGW: %MINGW%

rem ---------------------------------------------------------- 3. Compile
echo [3/4] Compiling...
set "PATH=%MINGW%;%QTDIR%\bin;%PATH%"
if exist "%BLD%" rmdir /s /q "%BLD%"
"%CMAKE%" -S "%ROOT%" -B "%BLD%" -G "MinGW Makefiles" -DCMAKE_PREFIX_PATH="%QTDIR%" -DCMAKE_BUILD_TYPE=Release -DCMAKE_MAKE_PROGRAM="%MINGW%\mingw32-make.exe"
if errorlevel 1 goto fail
"%CMAKE%" --build "%BLD%" --config Release -j 4
if errorlevel 1 goto fail
if not exist "%BLD%\SortieApp.exe" (
    echo ERROR: SortieApp.exe was not produced.
    goto fail
)

rem ---------------------------------------------------------- 4. Package into Output
echo [4/4] Packaging into Output folder...
if exist "%OUT%" rmdir /s /q "%OUT%"
mkdir "%OUT%"
copy /y "%BLD%\SortieApp.exe" "%OUT%\" >nul
"%QTDIR%\bin\windeployqt.exe" --release --no-translations "%OUT%\SortieApp.exe"
if errorlevel 1 goto fail
copy /y "%ROOT%\README.md" "%OUT%\" >nul 2>&1

echo.
echo ==========================================================
echo   SUCCESS!  Your app is ready:
echo   %OUT%\SortieApp.exe
echo   (the whole Output folder is portable - copy it anywhere)
echo ==========================================================
start "" "%OUT%"
pause
exit /b 0

rem ---------------------------------------------------------- helpers
:detect
set "QTDIR="
set "MINGW="
for /d %%D in ("%TC%\Qt\6.*") do if exist "%%D\mingw_64\bin\Qt6Core.dll" set "QTDIR=%%D\mingw_64"
if not defined QTDIR for /d %%D in ("C:\Qt\6.*") do if exist "%%D\mingw_64\bin\Qt6Core.dll" set "QTDIR=%%D\mingw_64"
for /d %%D in ("%TC%\Qt\Tools\mingw*_64") do if exist "%%D\bin\mingw32-make.exe" set "MINGW=%%D\bin"
if not defined MINGW for /d %%D in ("C:\Qt\Tools\mingw*_64") do if exist "%%D\bin\mingw32-make.exe" set "MINGW=%%D\bin"
exit /b 0

:ensure_python
set "PY="
if exist "%TC%\python\python.exe" (
    set "PY=%TC%\python\python.exe"
    exit /b 0
)
python -c "import sys; sys.exit(0 if sys.version_info>=(3,9) else 1)" >nul 2>&1
if not errorlevel 1 (
    set "PY=python"
    exit /b 0
)
echo       Python 3.9+ not found - installing Python %PYVER% locally ...
curl -L --fail -o "%TC%\python_setup.exe" "https://www.python.org/ftp/python/%PYVER%/python-%PYVER%-amd64.exe"
if errorlevel 1 exit /b 1
start /wait "" "%TC%\python_setup.exe" /quiet InstallAllUsers=0 TargetDir="%TC%\python" PrependPath=0 Include_launcher=0 Include_test=0 Include_doc=0 Shortcuts=0 AssociateFiles=0
del /q "%TC%\python_setup.exe" 2>nul
if not exist "%TC%\python\python.exe" exit /b 1
set "PY=%TC%\python\python.exe"
exit /b 0

:fail
echo.
echo ==========================================================
echo   BUILD FAILED. Scroll up to see the first error message.
echo   Common fixes: check internet connection, then run again
echo   (finished steps are skipped automatically).
echo ==========================================================
pause
exit /b 1

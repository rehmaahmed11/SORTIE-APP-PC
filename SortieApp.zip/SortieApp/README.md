# Sortie (Petal Wheel) - floating drop-zone file sorter

C++17 / Qt 6 desktop widget. Drag files or folders onto the circle, pick a folder "petal", done.

## Build (Windows 10 64-bit): double-click BUILD_SORTIE.bat
It downloads any missing tools (CMake, Python, Qt 6, MinGW) into _toolchain, compiles, and puts the finished app in the Output folder.

Linux/macOS: `./build_linux_mac.sh`

## Use
- Drag the circle anywhere. Mouse wheel = resize. Double-click = reset size.
- Drop file(s) on it -> menu: **Add New Folder...** or choose a petal -> **Move File Here**.
- Right-click: add folder, reset size, always-on-top toggle, quit. Tray icon also has Quit.
- Settings live in `petals_config.json` next to the exe (falls back to the user config folder if read-only).

## Safety (from the plan's arbitration)
- Config saved atomically (QSaveFile temp + rename).
- Cross-drive moves: copy -> verify size -> delete original; partial copies are rolled back.
- Never overwrites: name clashes become `name_copy1.ext`, `name_copy2.ext`...
- Remove Petal only removes the shortcut, never the real folder.

## Layout
```
CMakeLists.txt  resources.qrc  build_windows.bat  build_linux_mac.sh
src/  main.cpp  DropZoneWidget.{h,cpp}  FileMover.{h,cpp}  Config.{h,cpp}  Theme.h
assets/icons/*.svg
```
